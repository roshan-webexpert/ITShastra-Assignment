export class Student {
    _id: string;
    studentid: Number;
  studentname: string;
  studentage: Number;
  studentaddress: string;
  studenteducation: string;
  studentdob: string;
  studentgender: string;
  studentinterested: string;
}
