export interface IEducation{
    id: Number;
    name: String
}