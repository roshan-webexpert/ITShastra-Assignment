const express = require('express');
var router = express.Router();
var ObjectId = require('mongoose').Types.ObjectId;

var { studentlist } = require('../models/studentlist');


router.get('/', (req, res) => {
    studentlist.find((err, docs) => {
        if (!err) { res.send(docs); }
        else { console.log('Error in Retriving Studentlists :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.get('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    studentlist.findById(req.params.id, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in Retriving Employee :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.post('/', (req, res) => {
    var student = new studentlist({
        studentid: req.body.studentid,
        studentname: req.body.studentname,
        studentage: req.body.studentage,
        studentaddress: req.body.studentaddress,
        studenteducation: req.body.studenteducation,
        studentdob: req.body.studentdob,
        studentgender: req.body.studentgender,
        studentinterested: req.body.studentinterested,
    });
    student.save((err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in Studentlist Save :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.put('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    var student= {
        studentid: req.body.studentid,
        studentname: req.body.studentname,
        studentage: req.body.studentage,
        studentaddress: req.body.studentaddress,
        studenteducation: req.body.studenteducation,
        studentdob: req.body.studentdob,
        studentgender: req.body.studentgender,
        studentinterested: req.body.studentinterested,
    };
    studentlist.findByIdAndUpdate(req.params.id, { $set: student }, { new: true }, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in Employee Update :' + JSON.stringify(err, undefined, 2)); }
    });
});

router.delete('/:id', (req, res) => {
    if (!ObjectId.isValid(req.params.id))
        return res.status(400).send(`No record with given id : ${req.params.id}`);

    studentlist.findByIdAndRemove(req.params.id, (err, doc) => {
        if (!err) { res.send(doc); }
        else { console.log('Error in Employee Delete :' + JSON.stringify(err, undefined, 2)); }
    });
}); 

module.exports=router;