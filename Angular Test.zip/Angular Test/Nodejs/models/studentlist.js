const mongoose = require('mongoose');

var studentlist = mongoose.model('studentlist', {
    studentid: { type: Number },
    studentname: { type: String },
    studentage: { type: Number },
    studentaddress: { type: String },
    studenteducation: { type: String },
    studentdob: { type: String },
    studentgender: { type: String },
    studentinterested: { type: String },
});

module.exports = { studentlist };